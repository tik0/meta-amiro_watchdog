/*
 * Omnivision OV5647 CMOS Image Sensor driver
 *
 * Copyright (C) 2014, Stefan Herbrechtsmeier <stefan@herbrechtsmeier.net>
 *
 * Based on the MT9P031 driver.
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 */
#include <linux/clk.h>
#include <linux/delay.h>
#include <linux/gpio.h>
#include <linux/gpio/consumer.h>
#include <linux/i2c.h>
#include <linux/kernel.h>
#include <linux/media.h>
#include <linux/module.h>
#include <linux/regmap.h>
#include <linux/ratelimit.h>
#include <linux/of.h>
#include <linux/slab.h>
#include <linux/videodev2.h>

#include <media/media-entity.h>
#include <media/v4l2-ctrls.h>
#include <media/v4l2-device.h>
#include <media/v4l2-image-sizes.h>
#include <media/v4l2-subdev.h>
#include <media/v4l2-mediabus.h>

/*
 * Default values
 */
#define OV5647_CHIP_ID		0x5647

#define OV5647_MIN_WIDTH	2
#define OV5647_MIN_HEIGHT	2
#define OV5647_SENSOR_WIDTH	2624
#define OV5647_SENSOR_HEIGHT	1956
#define OV5647_ACTIVE_WIDTH	2592
#define OV5647_ACTIVE_HEIGHT	1944
#define OV5647_DUMMY_WIDTH	(OV5647_SENSOR_WIDTH - OV5647_ACTIVE_WIDTH)
#define OV5647_DUMMY_HEIGHT	(OV5647_SENSOR_HEIGHT - OV5647_ACTIVE_HEIGHT)

#define OV5647_X_INC_MAX	8
#define OV5647_Y_INC_MAX	8

/*
 * Registers
 */
#define OV5647_SOFT_SLEEP			0x0100
#define OV5647_SOFT_RESET			0x0103
#define OV5647_SC_CMMN_PAD_OEN0			0x3000
#define OV5647_SC_CMMN_PAD_OEN1			0x3001
#define OV5647_SC_CMMN_PAD_OEN2			0x3002
#define OV5647_SC_CMMN_CHIP_ID_MSB		0x300a
#define OV5647_SC_CMMN_CHIP_ID_LSB		0x300b
#define OV5647_SC_CMMN_PAD_PK			0x3011
#define OV5647_SC_CMMN_A_PWC_PK_O		0x3013
#define OV5647_SC_CMMN_A_PWC_PK_O_BP_REG	(1 << 3)
#define OV5647_SC_CMMN_PLL_CTRL0		0x3034
#define OV5647_SC_CMMN_PLL_CTRL1		0x3035
#define OV5647_SC_CMMN_PLL_CTRL1_SYS_CLK_DIV	(0xf << 4)
#define OV5647_SC_CMMN_PLL_MULTIPLIER		0x3036
#define OV5647_SC_CMMN_PLL_CTRL3		0x3037
#define OV5647_SC_CMMN_PLL_CTRL3_PLL_PREDIV	(0xf << 0)
#define OV5647_SC_CMMN_PLL_CTRL3_PLL_ROOT_DIV	(1 << 4)
#define OV5647_SC_CMMN_PLLS_CTRL2		0x303C
#define OV5647_SC_CMMN_PLLS_CTRL2_PLLS_SYS_DIV	(0xf << 0)
#define OV5647_GROUP_ACCESS			0x3208
#define OV5647_GROUP_ACCESS_GROUP0		(0x0 << 0)
#define OV5647_GROUP_ACCESS_GROUP1		(0x1 << 0)
#define OV5647_GROUP_ACCESS_GROUP2		(0x2 << 0)
#define OV5647_GROUP_ACCESS_GROUP3		(0x3 << 0)
#define OV5647_GROUP_ACCESS_ENTER_WRITE_MODE	(0x0 << 4)
#define OV5647_GROUP_ACCESS_EXIT_WRITE_MODE	(0x1 << 4)
#define OV5647_GROUP_ACCESS_INITIATE_WRITE	(0xa << 4)
#define OV5647_EXPOSURE				0x3500
#define OV5647_MANUAL_CTRL			0x3503
#define OV5647_MANUAL_CTRL_AEC_MANUAL		(1 << 0)
#define OV5647_MANUAL_CTRL_AGC_MANUAL		(1 << 1)
#define OV5647_MANUAL_CTRL_VTS_MANUAL		(1 << 2)
#define OV5647_AGC				0x350a
#define OV5647_VTS_DIFF_MSB			0x350c
#define OV5647_VTS_DIFF_LSB			0x350d
#define OV5647_TIMING_X_ADDR_START		0x3800
#define OV5647_TIMING_Y_ADDR_START		0x3802
#define OV5647_TIMING_X_ADDR_END		0x3804
#define OV5647_TIMING_Y_ADDR_END		0x3806
/* Number of active output pixels per line */
#define OV5647_TIMING_X_OUTPUT_SIZE		0x3808
/* Number of active output lines */
#define OV5647_TIMING_Y_OUTPUT_SIZE		0x380a
/* Number of output pixels per line */
#define OV5647_TIMING_HTS			0x380c
/* Number of output lines */
#define OV5647_TIMING_VTS			0x380e
#define OV5647_TIMING_X_INC			0x3814
#define OV5647_TIMING_Y_INC			0x3815
#define OV5647_TIMING_TC_REG20			0x3820
#define OV5647_TIMING_TC_REG20_VBIN		(1 << 0)
#define OV5647_TIMING_TC_REG20_VFLIP_SNR	(1 << 1)
#define OV5647_TIMING_TC_REG20_VFLIP_ISP	(1 << 2)
#define OV5647_TIMING_TC_REG21			0x3821
#define OV5647_TIMING_TC_REG21_HBIN		(1 << 0)
#define OV5647_TIMING_TC_REG21_MIRROR_SNR	(1 << 1)
#define OV5647_TIMING_TC_REG21_MIRROR_ISP	(1 << 2)
#define OV5647_WPT				0x3a0f
#define OV5647_BPT				0x3a10
#define OV5647_HIGH_VPT				0x3a11
#define OV5647_AEC_GAIN_CEILING_MSB		0x3a18
#define OV5647_AEC_GAIN_CEILING_LSB		0x3a19
#define OV5647_WPT2				0x3a1b
#define OV5647_BPT2				0x3a1e
#define OV5647_LOW_VPT				0x3a1f
#define OV5647_50_60_HZ_DETECTION_CTRL01	0x3c01
#define OV5647_50_60_HZ_DETECTION_CTRL01_EN	(1 << 7)
/* VSYNC length in terms of line count */
#define OV5647_BLC_CTRL00			0x4000
#define OV5647_BLC_CTRL00_BLC_ENABLE		(1 << 0)
#define OV5647_BLC_CTRL00_ADC_11BIT_MODE	(1 << 3)
#define OV5647_BLC_CTRL00_BLC_MEDIAN_FILTER	(1 << 7)
#define OV5647_BLC_CTRL01_START_LINE		0x4001
#define OV5647_BLC_CTRL04_BLC_LINE_NUM		0x4004
#define OV5647_BLC_CTRL05			0x4005
#define OV5647_BLC_CTRL05_BLC_ALWAYS_UPDATE	(1 << 1)
#define OV5647_BLC_CTRL05_BLC_MAN_1		(1 << 3)
#define OV5647_BLC_CTRL05_REMOVE_NONE_IMAGEDATA	(1 << 4)
#define OV5647_BLC_STABLE_RANGE			0x4051
#define OV5647_VSYNC_WIDTH			0x4701
/* VSYNC length in terms of pixel */
#define OV5647_VSYNC_NEG_WIDTH_MSB		0x4702
#define OV5647_VSYNC_NEG_WIDTH_LSB		0x4703
#define OV5647_DVP_POL_CTRL			0x4708
#define OV5647_ISP_CTRL00			0x5000
#define OV5647_ISP_CTRL00_WC_EN			(1 << 0)
#define OV5647_ISP_CTRL00_BC_EN			(1 << 1)
#define OV5647_ISP_CTRL00_LENC_EN		(1 << 7)
#define OV5647_ISP_CTRL01			0x5001
#define OV5647_ISP_CTRL01_AWB_EN		(1 << 0)
#define OV5647_ISP_CTRL03			0x5003
#define OV5647_ISP_CTRL03_BIN_AUTO_EN		(1 << 1)
#define OV5647_ISP_CTRL03_BIN_MAN_SET		(1 << 2)
#define OV5647_ISP_CTRL03_BIN_BUF_EN		(1 << 3)
#define OV5647_ISP_CTRL3D			0x503D
#define OV5647_ISP_CTRL3D_TEST_PATTERN_BAR	(0x0 << 0)
#define OV5647_ISP_CTRL3D_TEST_PATTERN_SQUARE	(0x1 << 0)
#define OV5647_ISP_CTRL3D_BAR_STYLE(x)		((x & 0x3) << 2)
#define OV5647_ISP_CTRL3D_SQU_BW_MODE		(1 << 4)
#define OV5647_ISP_CTRL3D_ROLLING_BAR		(1 << 6)
#define OV5647_ISP_CTRL3D_TEST_PATTERN_EN	(1 << 7)
#define OV5647_AWB_CTRL				0x5180
#define OV5647_AWB_CTRL_GAIN_MAN_EN		(1 << 3)
#define OV5647_MANUAL_RED_GAIN_MSB		0x5186
#define OV5647_MANUAL_RED_GAIN_LSB		0x5187
#define OV5647_MANUAL_GREEN_GAIN_MSB		0x5188
#define OV5647_MANUAL_GREEN_GAIN_LSB		0x5189
#define OV5647_MANUAL_BLUE_GAIN_MSB		0x518a
#define OV5647_MANUAL_BLUE_GAIN_LSB		0x518b
#define OV5647_DIGC_CTRL0			0x5a00

struct ov5647 {
	struct v4l2_subdev subdev;
	struct media_pad pad;
	enum v4l2_mbus_type bus_type;
	struct v4l2_rect crop;
	struct v4l2_mbus_framefmt format;
	struct v4l2_ctrl_handler ctrls;
	struct v4l2_ctrl *pixelrate;

	struct regmap *regmap;
	struct clk *clk;
	struct gpio_desc *powerdown;
	struct gpio_desc *reset;

	struct mutex lock;

	int power;

	unsigned int setup_fmt:1;
	unsigned int setup_ctrls:1;
};

static struct ov5647 *to_ov5647(struct v4l2_subdev *subdev)
{
	return container_of(subdev, struct ov5647, subdev);
}


static int ov5647_group_write(struct ov5647 *ov5647, unsigned int reg,
			      const void *val, size_t val_count)
{
	int ret;

	ret = regmap_write(ov5647->regmap, OV5647_GROUP_ACCESS,
			   OV5647_GROUP_ACCESS_ENTER_WRITE_MODE);
	if (ret < 0)
		return ret;

	ret = regmap_bulk_write(ov5647->regmap, reg, val, val_count);
	if (ret < 0)
		return ret;

	ret = regmap_write(ov5647->regmap, OV5647_GROUP_ACCESS,
			   OV5647_GROUP_ACCESS_EXIT_WRITE_MODE);
	if (ret < 0)
		return ret;

	return  regmap_write(ov5647->regmap, OV5647_GROUP_ACCESS,
			     OV5647_GROUP_ACCESS_INITIATE_WRITE);
}


static void ov5647_set_power(struct ov5647 *ov5647, int on)
{
	if (on) {
		clk_set_rate(ov5647->clk, 24000000);
		clk_prepare_enable(ov5647->clk);
		gpiod_set_value_cansleep(ov5647->powerdown, 0);
		gpiod_set_value_cansleep(ov5647->reset, 0);
		usleep_range(20000, 21000);
	} else {
		gpiod_set_value_cansleep(ov5647->powerdown, 1);
		gpiod_set_value_cansleep(ov5647->reset, 1);
		clk_disable_unprepare(ov5647->clk);
	}
}

static int ov5647_reset(struct ov5647 *ov5647)
{
	int ret;

	ret = regmap_write(ov5647->regmap, OV5647_SOFT_RESET, 0x1);
	if (ret < 0)
		return ret;

	msleep(5);

	return ret;
}

static int ov5647_set_sleep(struct ov5647 *ov5647, int on)
{
	return regmap_write(ov5647->regmap, OV5647_SOFT_SLEEP,
			    on ? 0x0 : 0x1);
}

static const struct reg_default ov5647_output_enable_regs[] = {
	{
		.reg = OV5647_SC_CMMN_PAD_OEN0,
		.def = 0xf,
	}, {
		.reg = OV5647_SC_CMMN_PAD_OEN1,
		.def = 0xff,
	}, {
		.reg = OV5647_SC_CMMN_PAD_OEN2,
		.def = 0xe4,
	},
};

static const struct reg_default ov5647_output_disable_regs[] = {
	{
		.reg = OV5647_SC_CMMN_PAD_OEN0,
		.def = 0x0,
	}, {
		.reg = OV5647_SC_CMMN_PAD_OEN1,
		.def = 0x0,
	}, {
		.reg = OV5647_SC_CMMN_PAD_OEN2,
		.def = 0x0,
	},
};

static int ov5647_set_output(struct ov5647 *ov5647, int on)
{
	struct reg_default *regs;
	int num;
  
	if (on) {
		regs = &ov5647_output_enable_regs[0];
		num = ARRAY_SIZE(ov5647_output_enable_regs);
	} else {
		regs = &ov5647_output_disable_regs[0];
		num = ARRAY_SIZE(ov5647_output_disable_regs);
	}

	return regmap_multi_reg_write(ov5647->regmap, regs, num);
}

/* input 6 ~ 27 MHz */
/* internal 96 MHz */
static int ov5647_set_pll(struct ov5647 *ov5647)
{
	struct regmap *regmap = ov5647->regmap;
	unsigned int mclk;
	unsigned int clkdiv = 2;
	unsigned int clkmulti = 60; // 74
	unsigned int prediv = 3;
	unsigned int pclk;
	int ret;

	mclk = clk_get_rate(ov5647->clk);

	ret = regmap_write(regmap, OV5647_SC_CMMN_PLL_CTRL0, 0x1a);
	if (ret < 0)
		return ret;

	/* PLLS_PRE_DIV = 3 */

	clkdiv = clamp_t(unsigned int, clkdiv, 1, 15);
	ret = regmap_update_bits(regmap, OV5647_SC_CMMN_PLL_CTRL1,
				 OV5647_SC_CMMN_PLL_CTRL1_SYS_CLK_DIV,
				 clkdiv << 4);
	if (ret < 0)
		return ret;

	ret = regmap_update_bits(regmap, OV5647_SC_CMMN_PLLS_CTRL2,
				 OV5647_SC_CMMN_PLLS_CTRL2_PLLS_SYS_DIV,
				 clkdiv);
	if (ret < 0)
		return ret;

	clkmulti = clamp_t(unsigned int, clkmulti, 4, 252);
	if (clkmulti > 127)
		clkmulti = ALIGN(clkmulti, 2);

	ret = regmap_write(regmap, OV5647_SC_CMMN_PLL_MULTIPLIER, clkmulti);
	if (ret < 0)
		return ret;

	prediv = clamp_t(unsigned int, prediv, 1, 4);
	ret = regmap_update_bits(regmap, OV5647_SC_CMMN_PLL_CTRL3,
				 OV5647_SC_CMMN_PLL_CTRL3_PLL_PREDIV,
				 prediv);
	if (ret < 0)
		return ret;

	pclk = mclk / 10 / prediv * clkmulti / clkdiv;

	v4l2_ctrl_s_ctrl_int64(ov5647->pixelrate, pclk);
	
	printk(KERN_INFO "%s: %d MHz -> %d MHz\n", __func__, mclk, pclk);
	return 0;
}

static const struct reg_default ov5647_default_regs[] = {
	{
		.reg = OV5647_SC_CMMN_PAD_PK, /* drive strength */
//		.def = 0x02, /* default */
		.def = 0x42, /* HengJun */
//		.def = 0x22, /* raymonxiu */
	}, {
		.reg = OV5647_SC_CMMN_A_PWC_PK_O,
		.def = OV5647_SC_CMMN_A_PWC_PK_O_BP_REG,
	}, {
		.reg = OV5647_DVP_POL_CTRL,
		.def = 0x00,
	}, {
		.reg = OV5647_ISP_CTRL00,
//		.def = 0xff, /* default */
		.def = OV5647_ISP_CTRL00_WC_EN
		     | OV5647_ISP_CTRL00_BC_EN /* raymonxiu */
		     /*| OV5647_ISP_CTRL00_LENC_EN*/,
	}, {
		.reg = OV5647_ISP_CTRL01,
		.def = OV5647_ISP_CTRL01_AWB_EN, /* default, HengJun */
//		.def = 0x00, /* raymonxiu */
	}, {
		.reg = OV5647_ISP_CTRL03,
		.def = OV5647_ISP_CTRL03_BIN_BUF_EN 
		     | OV5647_ISP_CTRL03_BIN_AUTO_EN, /* default, raymonxiu */
	}, {
		.reg = OV5647_DIGC_CTRL0,
		.def = 0x08, /* unknown */
	}, {
		.reg = OV5647_AEC_GAIN_CEILING_MSB,
		.def = 0x01,
	}, {
		.reg = OV5647_AEC_GAIN_CEILING_LSB,
		.def = 0xe0,
	}, {
		.reg = OV5647_50_60_HZ_DETECTION_CTRL01,
		.def = OV5647_50_60_HZ_DETECTION_CTRL01_EN,
	}, {
		.reg = 0x3630, /* unknown */
		.def = 0x2e,
	}, {
		.reg = 0x3632, /* unknown */
		.def = 0xe2,
	}, {
		.reg = 0x3633, /* unknown */
		.def = 0x23,
	}, {
		.reg = 0x3634, /* unknown */
		.def = 0x44,
	}, {
		.reg = 0x3620, /* unknown */
		.def = 0x64,
	}, {
		.reg = 0x3621, /* unknown */
		.def = 0xe0,
	}, {
		.reg = 0x3600, /* unknown */
		.def = 0x37,
	}, {
		.reg = 0x3704, /* unknown */
		.def = 0xa0,
	}, {
		.reg = 0x3703, /* unknown */
		.def = 0x5a,
	}, {
		.reg = 0x3715, /* unknown */
		.def = 0x78,
	}, {
		.reg = 0x3717, /* unknown */
		.def = 0x01,
	}, {
		.reg = 0x3731, /* unknown */
		.def = 0x02,
	}, {
		.reg = 0x370b, /* unknown */
		.def = 0x60,
	}, {
		.reg = 0x3705, /* unknown */
		.def = 0x1a,
	}, {
		.reg = 0x3f05, /* unknown */
		.def = 0x02,
	}, {
		.reg = 0x3f06, /* unknown */
		.def = 0x10,
	}, {
		.reg = 0x3f01, /* unknown */
		.def = 0x0a,
	},
#if 0
	/*
	 * Average based control function registers
	 */
	{
		 /* Stable range high limit (enter) */
		.reg = OV5647_WPT,
		.def = 0x58,
	}, {
		/* Stable range low limit (enter) */
		.reg = OV5647_BPT,
		.def = 0x50,
	}, {
		/* Stable range high limit (exit) */
		.reg = OV5647_WPT2,
		.def = 0x58,
	}, {
		/* Stable range low limit (exit) */
		.reg = OV5647_BPT2,
		.def = 0x50,
	}, {
		/* Fast zone high limit 
		 * when step ratio auto mode is disabled */
		.reg = OV5647_HIGH_VPT,
		.def = 0x60,
	}, {
		/* Fast zone low limit
		 * when step ratio auto mode is disabled */
		.reg = OV5647_LOW_VPT,
		.def = 0x28,
	},
#else
	/*
	 * Average based control function registers
	 */
	{
		 /* Stable range high limit (enter) */
		.reg = OV5647_WPT,
		.def = 0x38,
	}, {
		/* Stable range low limit (enter) */
		.reg = OV5647_BPT,
		.def = 0x30,
	}, {
		/* Stable range high limit (exit) */
		.reg = OV5647_WPT2,
		.def = 0x38,
	}, {
		/* Stable range low limit (exit) */
		.reg = OV5647_BPT2,
		.def = 0x30,
	}, {
		/* Fast zone high limit 
		 * when step ratio auto mode is disabled */
		.reg = OV5647_HIGH_VPT,
		.def = 0x40,
	}, {
		/* Fast zone low limit
		 * when step ratio auto mode is disabled */
		.reg = OV5647_LOW_VPT,
		.def = 0x18,
	},
#endif
#if 0
	/* Disable VTS */
	{
		.reg = OV5647_MANUAL_CTRL,
		.def = OV5647_MANUAL_CTRL_VTS_MANUAL,
	}, {
		.reg = OV5647_VTS_DIFF_MSB,
		.def = 0x00, /* raymonxiu */
	}, {
		.reg = OV5647_VTS_DIFF_LSB,
		.def = 0x00, /* raymonxiu */
	},
#endif
# if 0
/*
 * Auto white balance (AWB) registers
 */
	{
		.reg = OV5647_AWB_CTRL,
		.def = OV5647_AWB_CTRL_GAIN_MAN_EN,
	}, {
		.reg = OV5647_MANUAL_RED_GAIN_MSB,
		.def = 0x04,
	}, {
		.reg = OV5647_MANUAL_RED_GAIN_LSB,
		.def = 0x00,
	}, {
		.reg = OV5647_MANUAL_GREEN_GAIN_MSB,
		.def = 0x04,
	}, {
		.reg = OV5647_MANUAL_GREEN_GAIN_LSB,
		.def = 0x00,
	}, {
		.reg = OV5647_MANUAL_BLUE_GAIN_MSB,
		.def = 0x04,
	}, {
		.reg = OV5647_MANUAL_BLUE_GAIN_LSB,
		.def = 0x00,
	},
#endif
/* 
 * Black level calibration (BLC) registers
 */
	{
		.reg = OV5647_BLC_CTRL00,
		.def = OV5647_BLC_CTRL00_ADC_11BIT_MODE | OV5647_BLC_CTRL00_BLC_ENABLE,
	}, {
		.reg = OV5647_BLC_CTRL01_START_LINE,
		.def = 2,
	}, {
		.reg = OV5647_BLC_CTRL04_BLC_LINE_NUM,
		.def = 0x08, /* default, HengJun */
//		.def = 0x06, /* raymonxiu */
//		.def = 0x04, /* msm snap */
//		.def = 0x02, /* msm prev*/
	}, {
		.reg = 0x4005, /* BLC CTRL05 */
		.def = OV5647_BLC_CTRL05_REMOVE_NONE_IMAGEDATA
		     | OV5647_BLC_CTRL05_BLC_MAN_1
		     | OV5647_BLC_CTRL05_BLC_ALWAYS_UPDATE, /* HengJun, raymonxiu */
	}, {
		.reg = OV5647_BLC_STABLE_RANGE,
		.def = 0x7f, /* default, raymonxiu */
//		.def = 0x8f, /* HengJun */
	},
};

static int ov5647_init(struct ov5647 *ov5647)
{
	int ret;

	ov5647_reset(ov5647);
	if (ret < 0)
		return ret;

	ov5647_set_sleep(ov5647, 1);
	if (ret < 0)
		return ret;

	ret = regmap_multi_reg_write(ov5647->regmap, &ov5647_default_regs[0],
				     ARRAY_SIZE(ov5647_default_regs));
	
	return ret;
}

static int ov5647_s_power(struct v4l2_subdev *subdev, int on)
{
	struct ov5647 *ov5647 = to_ov5647(subdev);
	int ret = 0;

	v4l2_info(subdev, "%s power\n", on ? "Enable" : "Disable");

	mutex_lock(&ov5647->lock);
	if (ov5647->power == !on) {
		ov5647_set_power(ov5647, on);
/*		if (on) {
			ret = ov5647_init(ov5647);
		}
*/	}

	if (!ret)
		ov5647->power += on ? 1 : -1;

	WARN_ON(ov5647->power < 0);
	mutex_unlock(&ov5647->lock);

	return ret;
}

static int ov5647_enum_mbus_code(struct v4l2_subdev *subdev,
				 struct v4l2_subdev_fh *fh,
				 struct v4l2_subdev_mbus_code_enum *code)
{
	v4l2_info(subdev, "%s: %i\n", __func__, code->index);

	switch (code->index) {
	case 0:
		code->code = V4L2_MBUS_FMT_SBGGR10_1X10;
		break;
	case 1:
		code->code = V4L2_MBUS_FMT_SBGGR8_1X8;
		break;
	default:
		return -EINVAL;
	}

	return 0;
}

static int ov5647_enum_frame_sizes(struct v4l2_subdev *subdev,
				   struct v4l2_subdev_fh *fh,
				   struct v4l2_subdev_frame_size_enum *fse)
{
	v4l2_info(subdev, "%s: %i\n", __func__, fse->index);

	if (fse->index != 0)
		return -EINVAL;

	fse->min_width  = OV5647_MIN_WIDTH;
	fse->max_width  = OV5647_SENSOR_WIDTH;
	fse->min_height = OV5647_MIN_WIDTH;
	fse->max_height = OV5647_SENSOR_HEIGHT;

	return 0;
}

static struct v4l2_mbus_framefmt *
__ov5647_get_pad_format(struct ov5647 *ov5647, struct v4l2_subdev_fh *fh,
			 unsigned int pad, u32 which)
{
	switch (which) {
	case V4L2_SUBDEV_FORMAT_TRY:
		return v4l2_subdev_get_try_format(fh, pad);
	case V4L2_SUBDEV_FORMAT_ACTIVE:
		return &ov5647->format;
	default:
		return NULL;
	}
}

static struct v4l2_rect *
__ov5647_get_pad_crop(struct ov5647 *ov5647, struct v4l2_subdev_fh *fh,
		     unsigned int pad, u32 which)
{
	switch (which) {
	case V4L2_SUBDEV_FORMAT_TRY:
		return v4l2_subdev_get_try_crop(fh, pad);
	case V4L2_SUBDEV_FORMAT_ACTIVE:
		return &ov5647->crop;
	default:
		return NULL;
	}
}

static int ov5647_get_fmt(struct v4l2_subdev *subdev,
			  struct v4l2_subdev_fh *fh,
			  struct v4l2_subdev_format *fmt)
{
	struct ov5647 *ov5647 = to_ov5647(subdev);

	v4l2_info(subdev, "%s\n", __func__);

	fmt->format = *__ov5647_get_pad_format(ov5647, fh, fmt->pad,
						fmt->which);
	return 0;
}

static int ov5647_set_fmt(struct v4l2_subdev *subdev,
			  struct v4l2_subdev_fh *fh,
			  struct v4l2_subdev_format *format)
{
	struct ov5647 *ov5647 = to_ov5647(subdev);
	struct v4l2_mbus_framefmt *__format;
	struct v4l2_rect *__crop;
	unsigned int width;
	unsigned int height;
	unsigned int xratio;
	unsigned int yratio;

	v4l2_info(subdev, "%s\n", __func__);

	__crop = __ov5647_get_pad_crop(ov5647, fh, format->pad,
					format->which);

	width = clamp_t(unsigned int, ALIGN(format->format.width, 2),
			max_t(unsigned int, __crop->width / OV5647_X_INC_MAX,
			      2),
			__crop->width);
	height = clamp_t(unsigned int, ALIGN(format->format.height, 2),
			 max_t(unsigned int, __crop->height / OV5647_Y_INC_MAX,
			       2),
			 __crop->height);

	xratio = DIV_ROUND_CLOSEST(__crop->width, width);
	yratio = DIV_ROUND_CLOSEST(__crop->height, height);

	__format = __ov5647_get_pad_format(ov5647, fh, format->pad,
					    format->which);
	__format->width = __crop->width / xratio;
	__format->height = __crop->height / yratio;

	format->format = *__format;

	return 0;
}

static int ov5647_get_crop(struct v4l2_subdev *subdev,
			    struct v4l2_subdev_fh *fh,
			    struct v4l2_subdev_crop *crop)
{
	struct ov5647 *ov5647 = to_ov5647(subdev);

	v4l2_info(subdev, "%s\n", __func__);

	crop->rect = *__ov5647_get_pad_crop(ov5647, fh, crop->pad,
					     crop->which);
	return 0;
}

static int ov5647_set_crop(struct v4l2_subdev *subdev,
			    struct v4l2_subdev_fh *fh,
			    struct v4l2_subdev_crop *crop)
{
	struct ov5647 *ov5647 = to_ov5647(subdev);
	struct v4l2_mbus_framefmt *__format;
	struct v4l2_rect *__crop;
	struct v4l2_rect rect;

	v4l2_info(subdev, "%s\n", __func__);

	rect.left = clamp(ALIGN(crop->rect.left, 2), 0,
			  OV5647_ACTIVE_WIDTH - OV5647_MIN_WIDTH);
	rect.top = clamp(ALIGN(crop->rect.top, 2), 0,
			 OV5647_ACTIVE_HEIGHT - OV5647_MIN_HEIGHT);

	rect.width = clamp_t(unsigned int, ALIGN(crop->rect.width, 2),
			     OV5647_MIN_WIDTH, OV5647_ACTIVE_WIDTH);
	rect.height = clamp_t(unsigned int, ALIGN(crop->rect.height, 2),
			      OV5647_MIN_HEIGHT, OV5647_ACTIVE_HEIGHT);

	rect.width = min_t(unsigned int, rect.width,
			   OV5647_ACTIVE_WIDTH - rect.left);
	rect.height = min_t(unsigned int, rect.height,
			    OV5647_ACTIVE_HEIGHT - rect.top);

	__crop = __ov5647_get_pad_crop(ov5647, fh, crop->pad, crop->which);

	if (rect.width != __crop->width || rect.height != __crop->height) {
		/* Reset the output image size if the crop rectangle size has
		 * been modified.
		 */
		__format = __ov5647_get_pad_format(ov5647, fh, crop->pad,
						    crop->which);
		__format->width = rect.width;
		__format->height = rect.height;
	}

	*__crop = rect;
	crop->rect = rect;

	return 0;
}

static int ov5647_set_params(struct ov5647 *ov5647)
{
	struct regmap *regmap = ov5647->regmap;
	struct v4l2_mbus_framefmt *format = &ov5647->format;
	const struct v4l2_rect *crop = &ov5647->crop;
	unsigned int xratio;
	unsigned int yratio;	
	unsigned int xinc;
	unsigned int yinc;	
	unsigned int vbin;
	unsigned int hbin;
	unsigned int reg3612;
	unsigned int reg3618;
	unsigned int reg3708;
	unsigned int reg3709;
	unsigned int reg370c;
	__be16 word;
	int ret;
	unsigned char test[20];
	int i,j;

	xratio = crop->width / format->width;
	yratio = crop->height / format->height;

	word = cpu_to_be16(crop->left);
	ret = regmap_bulk_write(regmap, OV5647_TIMING_X_ADDR_START, &word, 2);
	if (ret < 0)
		return ret;

	word = cpu_to_be16(crop->top);
	ret = regmap_bulk_write(regmap, OV5647_TIMING_Y_ADDR_START, &word, 2);
	if (ret < 0)
		return ret;
	
	word = cpu_to_be16(crop->left + crop->width - 1 + xratio * 8);
	ret = regmap_bulk_write(regmap, OV5647_TIMING_X_ADDR_END, &word, 2);
	if (ret < 0)
		return ret;

	word = cpu_to_be16(crop->top + crop->height - 1 + yratio * 8);
	ret = regmap_bulk_write(regmap, OV5647_TIMING_Y_ADDR_END, &word, 2);
	if (ret < 0)
		return ret;

	word = cpu_to_be16(format->width);
	ret = regmap_bulk_write(regmap, OV5647_TIMING_X_OUTPUT_SIZE, &word, 2);
	if (ret < 0)
		return ret;

	word = cpu_to_be16(format->height);
	ret = regmap_bulk_write(regmap, OV5647_TIMING_Y_OUTPUT_SIZE, &word, 2);
	if (ret < 0)
		return ret;

	word = cpu_to_be16(2700); // 3200
	ret = regmap_bulk_write(regmap, OV5647_TIMING_HTS, &word, 2);
	if (ret < 0)
		return ret;

	word = cpu_to_be16(1968); // 2000
	ret = regmap_bulk_write(regmap, OV5647_TIMING_VTS, &word, 2);
	if (ret < 0)
		return ret;

	xinc = ((((2 * xratio) - 1) & 0xf) << 4) | 0x1;
	yinc = ((((2 * yratio) - 1) & 0xf) << 4) | 0x1;

	ret = regmap_write(regmap, OV5647_TIMING_X_INC, xinc);
	if (ret < 0)
		return ret;
	ret = regmap_write(regmap, OV5647_TIMING_Y_INC, yinc);
	if (ret < 0)
		return ret;

	printk(KERN_INFO "%s: %02x - %02x\n",
		       __func__, xinc, yinc);
	
	if ((xinc == 0x11) && (yinc == 0x11)) {
		vbin = 0x0;
		hbin = 0x0;
		reg3612 = 0x4b;
		reg3618 = 0x4;
		reg3708 = 0x24;
		reg3709 = 0x12;
		reg370c = 0x0;
	} else {
		vbin = OV5647_TIMING_TC_REG20_VBIN;
		hbin = OV5647_TIMING_TC_REG21_HBIN;
		reg3612 = 0x49;
		reg3618 = 0x0;
		reg3708 = 0x22;
		reg3709 = 0x52;
		reg370c = 0x3;
	}

	ret = regmap_update_bits(regmap, OV5647_TIMING_TC_REG20,
				 OV5647_TIMING_TC_REG20_VBIN, vbin);
	if (ret < 0)
		return ret;

	ret = regmap_update_bits(regmap, OV5647_TIMING_TC_REG20,
				 OV5647_TIMING_TC_REG21_HBIN, hbin);
	if (ret < 0)
		return ret;

	ret = regmap_write(regmap, 0x3612, reg3612);
	if (ret < 0)
		return ret;

	ret = regmap_write(regmap, 0x3618, reg3618);
	if (ret < 0)
		return ret;

	ret = regmap_write(regmap, 0x3708, reg3708);
	if (ret < 0)
		return ret;

	ret = regmap_write(regmap, 0x3709, reg3709);
	if (ret < 0)
		return ret;

	ret = regmap_write(regmap, 0x370c, reg370c);
	if (ret < 0)
		return ret;

	ret = regmap_bulk_read(regmap, OV5647_TIMING_X_ADDR_START, test, 20);
	if (ret < 0)
		return ret;

	for (i = 0; i < 10; i++) {
		j = 2 * i;
		printk(KERN_INFO "%s: %d %02x%02x\n",
		       __func__, i, test[j], test[j + 1]);
	}

	return 0;
}

static int ov5647_s_stream(struct v4l2_subdev *subdev, int enable)
{
	struct ov5647 *ov5647 = to_ov5647(subdev);
	int ret;

	v4l2_info(subdev, "%s\n", __func__);

	ov5647_set_sleep(ov5647, 1);
	if (ret < 0)
		return ret;
	
	if (!enable)
		return 0;

	ret = ov5647_init(ov5647);
	if (ret < 0)
		return ret;

	ret = ov5647_set_pll(ov5647);
	if (ret < 0)
		return ret;

	ret = ov5647_set_params(ov5647);
	if (ret < 0)
		return ret;

	ret = ov5647_set_output(ov5647, 1);
	if (ret < 0)
		return ret;

	ret = v4l2_ctrl_handler_setup(&ov5647->ctrls);
	if (ret < 0)
		return ret;

	ov5647_set_sleep(ov5647, 0);
	if (ret < 0)
		return ret;

	return 0;
}

static int ov5647_s_ctrl(struct v4l2_ctrl *ctrl)
{
	struct ov5647 *ov5647 = container_of(ctrl->handler, struct ov5647,
					     ctrls);
	struct regmap *regmap = ov5647->regmap;
	int value;
	int mask;
	__be32 dword;
	__be16 word;
	int ret = 0;

	v4l2_info(&ov5647->subdev, "%s\n", __func__);

	mutex_lock(&ov5647->lock);

	if (ov5647->power == 0)
		goto exit;

	switch (ctrl->id) {
	case V4L2_CID_AUTOGAIN:
		mask = OV5647_MANUAL_CTRL_AGC_MANUAL;
		value = ctrl->val ? 0 : mask;
		ret = regmap_update_bits(regmap, OV5647_MANUAL_CTRL,
					 mask, value);
		break;

	case V4L2_CID_GAIN:
		word = cpu_to_be16(ctrl->val);
		ret = ov5647_group_write(ov5647, OV5647_AGC, &word, 2);
		break;

	case V4L2_CID_EXPOSURE_AUTO:
		mask = OV5647_MANUAL_CTRL_AEC_MANUAL;
		value = (ctrl->val == V4L2_EXPOSURE_AUTO) ? 0 : mask;
		ret = regmap_update_bits(regmap, OV5647_MANUAL_CTRL,
					 mask, value);
		break;

	case V4L2_CID_EXPOSURE:
		dword = cpu_to_be32(ctrl->val << 8);
		ret = ov5647_group_write(ov5647, OV5647_EXPOSURE, &dword, 3);
		break;

	case V4L2_CID_HFLIP:
		mask = OV5647_TIMING_TC_REG21_MIRROR_ISP
		     | OV5647_TIMING_TC_REG21_MIRROR_SNR;
		value = ctrl->val ? mask : 0;
		ret = regmap_update_bits(regmap, OV5647_TIMING_TC_REG21,
					 mask, value);
		break;

	case V4L2_CID_VFLIP:
		mask = OV5647_TIMING_TC_REG20_VFLIP_ISP
		     | OV5647_TIMING_TC_REG20_VFLIP_SNR;
		value = ctrl->val ? mask : 0;
		ret = regmap_update_bits(regmap, OV5647_TIMING_TC_REG20,
					 mask, value);
		break;

	case V4L2_CID_TEST_PATTERN:
		switch (ctrl->val) {
		case 0:
			value = 0;
			break;
		case 5:
			value = OV5647_ISP_CTRL3D_TEST_PATTERN_SQUARE
			      | OV5647_ISP_CTRL3D_SQU_BW_MODE
			      | OV5647_ISP_CTRL3D_TEST_PATTERN_EN;
			break;
		case 6:
			value = OV5647_ISP_CTRL3D_TEST_PATTERN_SQUARE
			      | OV5647_ISP_CTRL3D_TEST_PATTERN_EN;
			break;
		case 7:
			value = OV5647_ISP_CTRL3D_TEST_PATTERN_BAR
			      | OV5647_ISP_CTRL3D_ROLLING_BAR
			      | OV5647_ISP_CTRL3D_TEST_PATTERN_EN;
			break;
		default:
			value = OV5647_ISP_CTRL3D_TEST_PATTERN_BAR
			      | OV5647_ISP_CTRL3D_BAR_STYLE(ctrl->val)
			      | OV5647_ISP_CTRL3D_TEST_PATTERN_EN;
			break;
		}
		ret = regmap_write(ov5647->regmap, OV5647_ISP_CTRL3D, value);
		break;
	}

exit:
	mutex_unlock(&ov5647->lock);
	return ret;
}

static struct v4l2_ctrl_ops ov5647_ctrl_ops = {
	.s_ctrl = ov5647_s_ctrl,
};

static const char * const ov5647_test_pattern_menu[] = {
	"Disabled",
	"Color Bar 1",
	"Color Bar 2",
	"Color Bar 3",
	"Color Bar 4",
	"Color Square",
	"Black-White Square",
	"Rolling Color Bar",
};

static const struct v4l2_subdev_core_ops ov5647_core_ops = {
	.s_power = ov5647_s_power,
};

static const struct v4l2_subdev_pad_ops ov5647_pad_ops = {
	.enum_mbus_code = ov5647_enum_mbus_code,
	.enum_frame_size = ov5647_enum_frame_sizes,
	.get_fmt = ov5647_get_fmt,
	.set_fmt = ov5647_set_fmt,
	.get_crop = ov5647_get_crop,
	.set_crop = ov5647_set_crop,
};

static const struct v4l2_subdev_video_ops ov5647_video_ops = {
	.s_stream = ov5647_s_stream,
//	.g_frame_interval = ov5647_g_frame_interval,
//	.s_frame_interval = ov5647_s_frame_interval,
};

static const struct v4l2_subdev_ops ov5647_subdev_ops = {
	.core = &ov5647_core_ops,
	.pad = &ov5647_pad_ops,
	.video = &ov5647_video_ops,
};

static int ov5647_detect_sensor(struct v4l2_subdev *subdev)
{
	struct ov5647 *ov5647 = to_ov5647(subdev);
	unsigned int high, low, id;
	int ret;

	mutex_lock(&ov5647->lock);
	ov5647_set_power(ov5647, 1);

	ret = regmap_read(ov5647->regmap, OV5647_SC_CMMN_CHIP_ID_MSB, &high);
	if (ret)
		goto exit;

	ret = regmap_read(ov5647->regmap, OV5647_SC_CMMN_CHIP_ID_LSB, &low);
	if (ret)
		goto exit;

	id = (high << 8) | low;

	if (id == OV5647_CHIP_ID) {
		v4l2_info(subdev, "Found OV%04X sensor\n", id);
	} else {
		v4l2_err(subdev, "Sensor detection failed (%04x)\n", id);
		ret = -ENODEV;
	}

exit:
	ov5647_set_power(ov5647, 0);
	mutex_unlock(&ov5647->lock);

	return ret;
}

static const struct regmap_config ov5647_regmap_config = {
	.reg_bits = 16,
	.val_bits = 8,
	.max_register = 0x5fff,
};

static int ov5647_probe(struct i2c_client *client,
			const struct i2c_device_id *id)
{
	struct v4l2_subdev *subdev;
	struct ov5647 *ov5647;
	int ret;

	ov5647 = devm_kzalloc(&client->dev, sizeof(*ov5647), GFP_KERNEL);
	if (!ov5647)
		return -ENOMEM;

	ov5647->clk = devm_clk_get(&client->dev, NULL);
	if (IS_ERR(ov5647->clk)) {
		dev_err(&client->dev, "Unable to get clock\n");
		return PTR_ERR(ov5647->clk);
	}

	ov5647->powerdown = devm_gpiod_get(&client->dev, "powerdown");
	if (IS_ERR(ov5647->powerdown)) {
		if (ov5647->powerdown != ERR_PTR(-ENOENT)) {
			dev_err(&client->dev, "Unable to get powerdown\n");
			return PTR_ERR(ov5647->powerdown);
		}
		ov5647->powerdown = NULL;
	}

	if (ov5647->powerdown) {
		ret = gpiod_direction_output(ov5647->powerdown, 1);
		if (ret)
			return ret;
	}

	ov5647->reset = devm_gpiod_get(&client->dev, "reset");
	if (IS_ERR(ov5647->reset)) {
		if (ov5647->reset != ERR_PTR(-ENOENT)) {
			dev_err(&client->dev, "Unable to get reset\n");
			return PTR_ERR(ov5647->reset);
		}
		ov5647->reset = NULL;
	}

	if (ov5647->reset) {
		ret = gpiod_direction_output(ov5647->reset, 0);
		if (ret)
			return ret;
	}

	ov5647->regmap = devm_regmap_init_i2c(client, &ov5647_regmap_config);
	if (IS_ERR(ov5647->regmap))
		return PTR_ERR(ov5647->regmap);

	v4l2_ctrl_handler_init(&ov5647->ctrls, 8);

	v4l2_ctrl_new_std(&ov5647->ctrls, &ov5647_ctrl_ops,
			  V4L2_CID_AUTOGAIN, 0, 1, 1, 1);
	v4l2_ctrl_new_std(&ov5647->ctrls, &ov5647_ctrl_ops,
			  V4L2_CID_GAIN, 0,
			  0x3ff, 1, 0); /* 0x007f both */
	v4l2_ctrl_new_std_menu(&ov5647->ctrls, &ov5647_ctrl_ops,
			       V4L2_CID_EXPOSURE_AUTO, V4L2_EXPOSURE_MANUAL, 0,
			       V4L2_EXPOSURE_AUTO);
	v4l2_ctrl_new_std(&ov5647->ctrls, &ov5647_ctrl_ops,
			  V4L2_CID_EXPOSURE, 0,
			  0xfffff, 1,  0x1080); /* 0x3c00 HengJun */ /* 0x1080 raymonxiu */
	v4l2_ctrl_new_std(&ov5647->ctrls, &ov5647_ctrl_ops,
			  V4L2_CID_HFLIP, 0, 1, 1, 0);
	v4l2_ctrl_new_std(&ov5647->ctrls, &ov5647_ctrl_ops,
			  V4L2_CID_VFLIP, 0, 1, 1, 0);
	v4l2_ctrl_new_std_menu_items(&ov5647->ctrls, &ov5647_ctrl_ops,
			  V4L2_CID_TEST_PATTERN,
			  ARRAY_SIZE(ov5647_test_pattern_menu) - 1, 0,
			  0, ov5647_test_pattern_menu);

	ov5647->pixelrate = v4l2_ctrl_new_std(&ov5647->ctrls, &ov5647_ctrl_ops,
					      V4L2_CID_PIXEL_RATE,
					      0, 0, 1, 42000000);

	ov5647->subdev.ctrl_handler = &ov5647->ctrls;

	if (ov5647->ctrls.error) {
		dev_err(&client->dev, " Control initialization error %d\n",
		        ov5647->ctrls.error);
		return ov5647->ctrls.error;
	}

	mutex_init(&ov5647->lock);

	subdev = &ov5647->subdev;
	v4l2_i2c_subdev_init(subdev, client, &ov5647_subdev_ops);

//	subdev->internal_ops = &ov5647_subdev_internal_ops;
	subdev->flags |= V4L2_SUBDEV_FL_HAS_DEVNODE;

	ov5647->pad.flags = MEDIA_PAD_FL_SOURCE;
	subdev->entity.type = MEDIA_ENT_T_V4L2_SUBDEV_SENSOR;
	ret = media_entity_init(&subdev->entity, 1, &ov5647->pad, 0);
	if (ret < 0)
		goto err;

	ret = ov5647_detect_sensor(subdev);
	if (ret < 0)
		goto err_entity;

	ov5647->format.width = OV5647_ACTIVE_WIDTH;
	ov5647->format.height = OV5647_ACTIVE_HEIGHT;
	ov5647->format.field = V4L2_FIELD_NONE;
	ov5647->format.colorspace = V4L2_COLORSPACE_SRGB;
	ov5647->format.code = V4L2_MBUS_FMT_SBGGR10_1X10;

	ov5647->crop.width = ov5647->format.width;
	ov5647->crop.height = ov5647->format.height;
	ov5647->crop.left = (OV5647_SENSOR_WIDTH - ov5647->crop.width) / 2;
	ov5647->crop.top = (OV5647_SENSOR_HEIGHT - ov5647->format.height) / 2;

	return 0;

err_entity:
	media_entity_cleanup(&subdev->entity);
err:
	v4l2_ctrl_handler_free(subdev->ctrl_handler);
	return ret;
}

static int ov5647_remove(struct i2c_client *client)
{
	struct v4l2_subdev *subdev = i2c_get_clientdata(client);

	v4l2_device_unregister_subdev(subdev);
//	v4l2_ctrl_handler_free(subdev->ctrl_handler);
	media_entity_cleanup(&subdev->entity);

	return 0;
}

static const struct i2c_device_id ov5647_id[] = {
	{ "ov5647", 0 },
	{ /* sentinel */ }
};
MODULE_DEVICE_TABLE(i2c, ov5647_id);

#if IS_ENABLED(CONFIG_OF)
static const struct of_device_id ov5647_of_match[] = {
	{ .compatible = "omnivision,ov5647", },
	{ /* sentinel */ },
};
MODULE_DEVICE_TABLE(of, ov5647_of_match);
#endif

static struct i2c_driver ov5647_i2c_driver = {
	.driver = {
		.name	= "ov5647",
	},
	.probe		= ov5647_probe,
	.remove		= ov5647_remove,
	.id_table	= ov5647_id,
};

module_i2c_driver(ov5647_i2c_driver);

MODULE_DESCRIPTION("Omnivision OV5647 CMOS Image Sensor driver");
MODULE_AUTHOR("Stefan Herbrechtsmeier <stefan@herbrechtsmeier.net>");
MODULE_LICENSE("GPL");
